package com.vinayjain.movieticketbooking.controller;

import com.vinayjain.movieticketbooking.dto.BookingDto;
import com.vinayjain.movieticketbooking.dto.MovieDto;
import com.vinayjain.movieticketbooking.service.MovieDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class BlogController {
    private MovieDetailsService movieDetailsService;

    public BlogController(MovieDetailsService movieDetailsService) {
        this.movieDetailsService = movieDetailsService;
    }
    @GetMapping("/")
    public String viewBlogMovies(Model model){
        List<MovieDto> moviesResponse=movieDetailsService.findAllMovies();

        model.addAttribute("moviesResponse",moviesResponse);
        return "blog/view_movies";
    }

    @GetMapping("/blog/BookMovie")
    public String BookAMovie(Model model){
        BookingDto bookingDto = new BookingDto();
        model.addAttribute("booking", bookingDto);
        return "blog/book_movie";
    }

}
