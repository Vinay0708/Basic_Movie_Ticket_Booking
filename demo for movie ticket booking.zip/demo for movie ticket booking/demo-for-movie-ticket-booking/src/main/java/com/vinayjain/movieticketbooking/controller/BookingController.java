package com.vinayjain.movieticketbooking.controller;

import com.vinayjain.movieticketbooking.dto.BookingDto;
import com.vinayjain.movieticketbooking.entity.Booking;
import com.vinayjain.movieticketbooking.service.BookingService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Random;

@Controller
public class BookingController {
    private BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @PostMapping("/BookUser/save")
    public String createBooking(@ModelAttribute("booking") Booking booking, Model model) {
        // Add any necessary logic to process the booking

        // Assuming the booking object is processed and now available for the view
        model.addAttribute("booking", booking);

        // Redirect to the checkout page
        return "blog/Checkout_page";
    }
    @PostMapping("/place-order")
    public String placeOrder(Booking booking, Model model) {
        // Process the booking details
        // For simplicity, generate a random receipt number
        Random random = new Random();
        int receiptNumber = random.nextInt(1000000);

        // Add the receipt number and booking object to the model
        model.addAttribute("receiptNumber", receiptNumber);
        model.addAttribute("booking", booking);

        // Redirect to the thank-you page
        return "blog/thank-you";
    }
}
