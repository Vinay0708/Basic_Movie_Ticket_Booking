package com.vinayjain.movieticketbooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoForMovieTicketBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoForMovieTicketBookingApplication.class, args);
	}

}
