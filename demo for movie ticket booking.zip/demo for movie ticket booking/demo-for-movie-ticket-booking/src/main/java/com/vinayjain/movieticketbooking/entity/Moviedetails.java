package com.vinayjain.movieticketbooking.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name="movies")
public class  Moviedetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String title;

    @Column(nullable = false)
    private String movieGenere;
    private String url;
    private String shortDescription;

//    @Lob
//    private byte[] image;


    private String address;

    @OneToMany(mappedBy = "moviedetails", cascade=CascadeType.REMOVE)
    private Set<Booking> bookingSet= new HashSet<>();
}
