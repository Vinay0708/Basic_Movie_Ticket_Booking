package com.vinayjain.movieticketbooking.service.impl;

import com.vinayjain.movieticketbooking.dto.BookingDto;
import com.vinayjain.movieticketbooking.entity.Booking;
import com.vinayjain.movieticketbooking.entity.Moviedetails;
import com.vinayjain.movieticketbooking.mapper.BookingMapper;
import com.vinayjain.movieticketbooking.repository.BookingRepository;
import com.vinayjain.movieticketbooking.repository.MovieDetailsRepository;
import com.vinayjain.movieticketbooking.service.BookingService;
import org.springframework.stereotype.Service;

@Service
public class BookingServiceImpl implements BookingService {

    private BookingRepository bookingRepository;
    private MovieDetailsRepository movieDetailsRepository;


    public BookingServiceImpl(BookingRepository bookingRepository, MovieDetailsRepository movieDetailsRepository) {
        this.bookingRepository = bookingRepository;
        this.movieDetailsRepository = movieDetailsRepository;
    }

    @Override
    public void createBooking(Long id, BookingDto bookingDto) {
        Moviedetails moviedetails = movieDetailsRepository.findById(id).get();
        Booking booking = BookingMapper.mapToBooking(bookingDto);
        booking.setMoviedetails(moviedetails);
        bookingRepository.save(booking);
    }
}
