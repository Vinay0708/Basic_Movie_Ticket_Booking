package com.vinayjain.movieticketbooking.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import lombok.*;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name="Bookings")
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private String name;
    @Column(nullable = false)
    private String email;
    @NotEmpty
    private Long contact_no;
    @NotEmpty
    private Long seats;

    @ManyToOne
    @JoinColumn(name = "moviedetails_id", nullable = false)
    private Moviedetails moviedetails;
}
