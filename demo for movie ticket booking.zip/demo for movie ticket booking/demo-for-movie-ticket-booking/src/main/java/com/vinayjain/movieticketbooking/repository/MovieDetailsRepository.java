package com.vinayjain.movieticketbooking.repository;

import com.vinayjain.movieticketbooking.entity.Moviedetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

public interface MovieDetailsRepository extends JpaRepository<Moviedetails,Long> {

    Optional<Moviedetails> findByTitle(String title);
    Optional<Moviedetails> findByUrl(String url);
}
