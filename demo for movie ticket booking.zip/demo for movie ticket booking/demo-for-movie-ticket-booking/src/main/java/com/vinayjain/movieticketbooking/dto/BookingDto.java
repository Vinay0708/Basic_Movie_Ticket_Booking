package com.vinayjain.movieticketbooking.dto;

import jakarta.persistence.Id;
import jakarta.validation.constraints.NotEmpty;
import lombok.*;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BookingDto {

    private Long id;

    @NotEmpty
    private String name;
    @NotEmpty
    private String email;
    @NotEmpty
    private Long contact_no;
    @NotEmpty
    private Long seats;
}
