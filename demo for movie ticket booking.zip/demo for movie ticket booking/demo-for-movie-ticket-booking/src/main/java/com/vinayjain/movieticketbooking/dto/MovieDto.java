package com.vinayjain.movieticketbooking.dto;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MovieDto {

    private Long id;
    @NotEmpty(message = "Title can not be Empty")
    private String title;
    private String url;
    @NotEmpty(message = "Movie Genere can not be Empty")
    private String movieGenere;
    @NotEmpty(message = "Please provide a short description")
    private String shortDescription;
    //private byte[] image;
    @NotEmpty(message = "Please Provide a valid address")
    private String address;
}
